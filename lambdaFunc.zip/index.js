
var http = require("https");
var async = require('asyncawait/async');
var await = require('asyncawait/await');
var OktaAPI = require('okta-node');
var okta = new OktaAPI("00CE0Aye9KNVwQfERxaCBnM9dOYbPADCbfU1uhGyF_", "vanbeektech");



var namely = function(){
var goodToGo;

return new Promise(function(resolve, reject) {

var options = {
  "method": "GET",
  "hostname": "intercom-sandbox.namely.com",
  "port": null,
  "path": "/api/v1/profiles",
  "headers": {
    "authorization": "Bearer JQfZZbHPSU6Q8tNs0KONleDzAxmxT1goN7qx29AyGihqa4F7DlvwlQeSLco5e1v5",
    "Accept": "application/json"
  }
};
var req = http.request(options, function (res) {
  var chunks = [];

  res.on("data", function (chunk) {
    chunks.push(chunk);
  });

  res.on("end", function () {
    var body = Buffer.concat(chunks);
    resolve(body.toString());
  });
});

req.write("{}");
req.end();






})

}




var oktaUpdate = function(userId, value) {
  var updated;

  return new Promise(function(resolve, reject) {


        okta.users.updatePartial("00u2f024j3iRnZHHH1t7", {testemail : value}, null, function(d){
          updated = "test"
          console.log(d)
          resolve(updated);
        });

  });
}







namely()

  const makeReset = async (function() {
        var otherthing = await (namely())
        console.log("test")
        var item = JSON.parse(otherthing);
        var firstPerson = item["profiles"][0]["email"]
        console.log(firstPerson)
        console.log("test")
        var something = await (oktaUpdate("00u2pf2nf1lcnOuTP1t7", item["profiles"][0]["email"]))


    });

    makeReset()


    exports.helloWorld = function helloWorld (req, res) {
      makeReset()
    };
